Brett	C.	Bushnell	-	bbushnell	-	ECE 474A
Matthew	R.	Dzurick		-	mdzurick	-	ECE 574A

December 7, 2016

Assignment 3

This assignment requires the user to supply a C-like Behavioral
Specification (cFile), the latency of the schedule (latency), 
and the name of the verilog file to be created (verilogFile).
The code shall take the C-like behavioral specification, create
the necessary scheduling to create a force-directed schedule.
This schedule shall be implemented in a verilog document containing
a minimized force-directed schedule in a high-level synthesizer.

The hlsyn does not attempt to achieve the 10% extra credit for for loops.